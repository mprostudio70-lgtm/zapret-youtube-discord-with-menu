@echo off
echo ....................................................
echo -----------------------impro_tv---------------------
echo ....................................................
echo  =====MENU=====
echo  0.restart menu
echo  1.general (ALT)
echo  2.general (ALT2)
echo  3.general (ALT3)
echo  4.general (ALT4)
echo  5.general (ALT5)
echo  6.general (ALT6)
echo  7.general (ALT7)
echo  8.general (ALT8)
echo  9.general (ALT9)
echo  10.general (ALT10)
echo  11.general (ALT11)
echo  fta.general (FAKE TLS AUTO ALT)
echo  fta2.general (FAKE TLS AUTO ALT2)
echo  fta3.general (FAKE TLS AUTO ALT3)
echo  ftam.general (FAKE TLS AUTO)
echo  sf.general (SIMPLE FAKE)
echo  sfa.general (SIMPLE FAKE  ALT)
echo  sfa2.general (SIMPLE FAKE  ALT2)
echo  s.service
echo  g.general
set /P choice="number: "

if "%choice%"=="1" (
   start "" "%~dp0general (ALT).bat"
)
if "%choice%"=="2" (
   start "" "%~dp0general (ALT2).bat"
)
if "%choice%"=="3" (
   start "" "%~dp0general (ALT3).bat"
)
if "%choice%"=="4" (
   start "" "%~dp0general (ALT4).bat"
)
if "%choice%"=="5" (
   start "" "%~dp0general (ALT5).bat"
)
if "%choice%"=="6" (
   start "" "%~dp0general (ALT6).bat"
)
if "%choice%"=="7" (
   start "" "%~dp0general (ALT7).bat"
)
if "%choice%"=="8" (
   start "" "%~dp0general (ALT8).bat"
)
if "%choice%"=="9" (
   start "" "%~dp0general (ALT9).bat"
)
if "%choice%"=="10" (
   start "" "%~dp0general (ALT10).bat"
)
if "%choice%"=="11" (
   start "" "%~dp0general (ALT11).bat"
)
if "%choice%"=="fta" (
   start "" "%~dp0general (FAKE TLS AUTO ALT).bat"
)
if "%choice%"=="fta2" (
   start "" "%~dp0general (FAKE TLS AUTO ALT2).bat"
)
if "%choice%"=="fta3" (
   start "" "%~dp0general (FAKE TLS AUTO ALT3).bat"
)
if "%choice%"=="ftam" (
   start "" "%~dp0general (FAKE TLS AUTO).bat"
)
if "%choice%"=="g" (
   start "" "%~dp0general.bat"
)
if "%choice%"=="s" (
   start "" "%~dp0service.bat"
)
if "%choice%"=="m" (
   start "" "%~dp0menu.bat"
   stop
)










